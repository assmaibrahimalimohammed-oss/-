import unittest
from add_numbers import add

class TestAddNumbers(unittest.TestCase):

    def test_add_positive(self):
        self.assertEqual(add(2, 3), 5)

    def test_add_zero(self):
        self.assertEqual(add(5, 0), 5)

    def test_add_negative(self):
        self.assertEqual(add(-2, 3), 1)

if _name_ == "_main_":
    unittest.main()