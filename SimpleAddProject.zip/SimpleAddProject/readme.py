# =========================================================
# Project: Simple Addition Program
# Language: Python
# Purpose: Program to add two numbers entered by the user
# How it works:
#   1. User inputs two numbers
#   2. Program calculates the sum using a function
#   3. Program prints the result
# Expected result:
#   - If user enters 5 and 3, output will be: Result: 8
# =========================================================

# -------------------------------
# Step 1: Define a function to add two numbers
# -------------------------------
def add(a, b):
    """
    This function takes two numbers 'a' and 'b' and returns their sum.
    """
    return a + b

# -------------------------------
# Step 2: Main program execution
# -------------------------------
if __name__ == "__main__":
    # The program asks the user to input the first number
    x = int(input("Enter first number: "))
    
    # The program asks the user to input the second number
    y = int(input("Enter second number: "))
    
    # Call the 'add' function to calculate the sum
    result = add(x, y)
    
    # Print the result to the user
    print("Result:", result)

# -------------------------------
# Step 3: How to run this program
# -------------------------------
# 1. Save this file as 'add_numbers_with_comments.py'
# 2. Open Terminal or Command Prompt in the folder where the file is saved
# 3. Type: python add_numbers_with_comments.py
# 4. Follow the prompts to enter two numbers
# 5.