def add(a, b):
    return a + b

if _name_ == "_main_":
    # السطور اللي داخل if لازم يكونوا أعمق بمسافة 4 من اليسار
    x = int(input("Enter first number: "))
    y = int(input("Enter second number: "))
    result = add(x, y)
    print("Result:", result)